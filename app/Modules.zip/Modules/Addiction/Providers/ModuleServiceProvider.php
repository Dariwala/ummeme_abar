<?php

namespace App\Modules\Addiction\Providers;

use Caffeinated\Modules\Support\ServiceProvider;

class ModuleServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the module services.
     *
     * @return void
     */
    public function boot()
    {
        $this->loadTranslationsFrom(__DIR__.'/../Resources/Lang', 'addiction');
        $this->loadViewsFrom(__DIR__.'/../Resources/Views', 'addiction');
        $this->loadMigrationsFrom(__DIR__.'/../Database/Migrations', 'addiction');
    }

    /**
     * Register the module services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->register(RouteServiceProvider::class);
    }
}
