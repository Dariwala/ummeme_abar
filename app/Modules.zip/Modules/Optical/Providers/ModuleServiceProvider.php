<?php

namespace App\Modules\Optical\Providers;

use Caffeinated\Modules\Support\ServiceProvider;

class ModuleServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the module services.
     *
     * @return void
     */
    public function boot()
    {
        $this->loadTranslationsFrom(__DIR__.'/../Resources/Lang', 'optical');
        $this->loadViewsFrom(__DIR__.'/../Resources/Views', 'optical');
        $this->loadMigrationsFrom(__DIR__.'/../Database/Migrations', 'optical');
    }

    /**
     * Register the module services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->register(RouteServiceProvider::class);
    }
}
